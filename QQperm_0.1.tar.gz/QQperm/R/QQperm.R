#' QQperm: A package for inflation factor estimation and QQ plot.
#' @author Slave Petrovski and Quanli Wang
#' @aliases qqperm
#' @docType package
#' @name QQperm
NULL
#> NULL

