#' QQperm: A package for permutation-based QQ plots and inflation factor estimates.
#' @author Slave Petrovski and Quanli Wang
#' @aliases qqperm
#' @docType package
#' @name QQperm
NULL
#> NULL


